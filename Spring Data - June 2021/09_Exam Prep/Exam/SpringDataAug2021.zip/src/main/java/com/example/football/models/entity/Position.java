package com.example.football.models.entity;

public enum Position {
    ATT, MID, DEF;
}
