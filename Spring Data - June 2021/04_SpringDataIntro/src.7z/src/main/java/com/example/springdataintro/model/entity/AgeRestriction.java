package com.example.springdataintro.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
